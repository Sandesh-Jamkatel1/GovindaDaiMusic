export async function mixAudio(bgFile: File, voiceFile: File, bgVolume: number, voiceVolume: number): Promise<Blob> {
  const audioContext = new AudioContext();
  
  // Load audio files
  const [bgBuffer, voiceBuffer] = await Promise.all([
    loadAudioFile(bgFile, audioContext),
    loadAudioFile(voiceFile, audioContext)
  ]);

  // Create offline context for rendering
  const offlineContext = new OfflineAudioContext({
    numberOfChannels: 2,
    length: Math.max(bgBuffer.length, voiceBuffer.length),
    sampleRate: audioContext.sampleRate
  });

  // Create audio sources
  const bgSource = offlineContext.createBufferSource();
  const voiceSource = offlineContext.createBufferSource();
  
  bgSource.buffer = bgBuffer;
  voiceSource.buffer = voiceBuffer;

  // Create gain nodes for volume control
  const bgGain = offlineContext.createGain();
  const voiceGain = offlineContext.createGain();
  
  bgGain.gain.value = bgVolume;
  voiceGain.gain.value = voiceVolume;

  // Connect nodes
  bgSource.connect(bgGain).connect(offlineContext.destination);
  voiceSource.connect(voiceGain).connect(offlineContext.destination);

  // Start playback
  bgSource.start(0);
  voiceSource.start(0);

  // Render audio
  const renderedBuffer = await offlineContext.startRendering();

  // Convert to WAV
  const wavBlob = await convertToWav(renderedBuffer);
  return wavBlob;
}

async function loadAudioFile(file: File, context: AudioContext): Promise<AudioBuffer> {
  const arrayBuffer = await file.arrayBuffer();
  return await context.decodeAudioData(arrayBuffer);
}

function convertToWav(audioBuffer: AudioBuffer): Promise<Blob> {
  const numOfChan = audioBuffer.numberOfChannels;
  const length = audioBuffer.length * numOfChan * 2;
  const buffer = new ArrayBuffer(44 + length);
  const view = new DataView(buffer);
  const channels = [];
  let sample = 0;
  let offset = 0;
  let pos = 0;

  // Write WAV header
  setUint32(0x46464952);                         // "RIFF"
  setUint32(36 + length);                        // file length
  setUint32(0x45564157);                         // "WAVE"
  setUint32(0x20746d66);                         // "fmt " chunk
  setUint32(16);                                 // length = 16
  setUint16(1);                                  // PCM (uncompressed)
  setUint16(numOfChan);
  setUint32(audioBuffer.sampleRate);
  setUint32(audioBuffer.sampleRate * 2 * numOfChan); // avg. bytes/sec
  setUint16(numOfChan * 2);                      // block-align
  setUint16(16);                                 // 16-bit
  setUint32(0x61746164);                         // "data" - chunk
  setUint32(length);                             // chunk length

  // Write interleaved data
  for (let i = 0; i < audioBuffer.numberOfChannels; i++) {
    channels.push(audioBuffer.getChannelData(i));
  }

  while (pos < audioBuffer.length) {
    for (let i = 0; i < numOfChan; i++) {
      sample = Math.max(-1, Math.min(1, channels[i][pos]));
      sample = (0.5 + sample < 0 ? sample * 32768 : sample * 32767) | 0;
      view.setInt16(44 + offset, sample, true);
      offset += 2;
    }
    pos++;
  }

  return new Blob([buffer], { type: "audio/wav" });

  function setUint16(data: number) {
    view.setUint16(pos, data, true);
    pos += 2;
  }

  function setUint32(data: number) {
    view.setUint32(pos, data, true);
    pos += 4;
  }
}