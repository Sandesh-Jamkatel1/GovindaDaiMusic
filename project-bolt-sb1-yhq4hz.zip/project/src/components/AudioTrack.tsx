import React, { useEffect, useRef } from 'react';
import WaveSurfer from 'wavesurfer.js';
import { Play, Pause, Volume2, RotateCcw } from 'lucide-react';

interface AudioTrackProps {
  file: File | null;
  volume: number;
  onVolumeChange: (value: number) => void;
  label: string;
  isLoop?: boolean;
  maxVolume?: number;
}

export default function AudioTrack({ file, volume, onVolumeChange, label, isLoop = false, maxVolume }: AudioTrackProps) {
  const waveformRef = useRef<HTMLDivElement>(null);
  const wavesurferRef = useRef<WaveSurfer | null>(null);
  const [isPlaying, setIsPlaying] = React.useState(false);

  useEffect(() => {
    if (waveformRef.current && file) {
      const wavesurfer = WaveSurfer.create({
        container: waveformRef.current,
        waveColor: '#4f46e5',
        progressColor: '#818cf8',
        cursorColor: '#312e81',
        barWidth: 2,
        barGap: 1,
        height: 80,
        normalize: true,
      });

      wavesurferRef.current = wavesurfer;
      wavesurfer.loadBlob(file);
      wavesurfer.setVolume(volume);
      
      if (isLoop) {
        wavesurfer.on('finish', () => {
          wavesurfer.play(0);
        });
      }

      return () => {
        wavesurfer.destroy();
      };
    }
  }, [file]);

  useEffect(() => {
    if (wavesurferRef.current) {
      wavesurferRef.current.setVolume(volume);
    }
  }, [volume]);

  const handlePlayPause = () => {
    if (wavesurferRef.current) {
      if (isPlaying) {
        wavesurferRef.current.pause();
      } else {
        wavesurferRef.current.play();
      }
      setIsPlaying(!isPlaying);
    }
  };

  const handleRestart = () => {
    if (wavesurferRef.current) {
      wavesurferRef.current.stop();
      wavesurferRef.current.play();
      setIsPlaying(true);
    }
  };

  return (
    <div className="w-full p-6 bg-white rounded-xl shadow-lg">
      <div className="flex items-center justify-between mb-4">
        <h3 className="text-lg font-semibold text-gray-800">{label}</h3>
        <div className="flex items-center gap-4">
          <button
            onClick={handlePlayPause}
            className="p-2 text-white bg-indigo-600 rounded-full hover:bg-indigo-700 transition-colors"
          >
            {isPlaying ? <Pause size={20} /> : <Play size={20} />}
          </button>
          <button
            onClick={handleRestart}
            className="p-2 text-white bg-indigo-600 rounded-full hover:bg-indigo-700 transition-colors"
          >
            <RotateCcw size={20} />
          </button>
          <div className="flex items-center gap-2">
            <Volume2 size={20} className="text-gray-600" />
            <input
              type="range"
              min="0"
              max={maxVolume || 1}
              step="0.01"
              value={volume}
              onChange={(e) => onVolumeChange(parseFloat(e.target.value))}
              className="w-24 h-2 bg-gray-200 rounded-lg appearance-none cursor-pointer"
            />
          </div>
        </div>
      </div>
      <div ref={waveformRef} className="w-full" />
    </div>
  );
}