import React, { useState, useEffect } from 'react';
import { Upload, Download, Music, Mic } from 'lucide-react';
import AudioTrack from './components/AudioTrack';
import { mixAudio } from './utils/audioMixer';

function App() {
  const [bgMusic, setBgMusic] = useState<File | null>(null);
  const [voiceOver, setVoiceOver] = useState<File | null>(null);
  const [bgVolume, setBgVolume] = useState(0.5); // Initial background volume lowered to 0.5
  const [voiceVolume, setVoiceVolume] = useState(1.0);
  const [isExporting, setIsExporting] = useState(false);

  // Ensure background volume stays 50% lower than voice volume
  const handleVoiceVolumeChange = (newVoiceVolume: number) => {
    setVoiceVolume(newVoiceVolume);
    setBgVolume(Math.min(newVoiceVolume * 0.2, 1)); // Changed from 0.7 to 0.5 (50% lower)
  };

  const handleBgVolumeChange = (newBgVolume: number) => {
    const maxBgVolume = voiceVolume * 0.2; // Changed from 0.7 to 0.5 (50% lower)
    setBgVolume(Math.min(newBgVolume, maxBgVolume));
  };

  const handleFileUpload = (event: React.ChangeEvent<HTMLInputElement>, type: 'bg' | 'voice') => {
    const file = event.target.files?.[0];
    if (file) {
      if (type === 'bg') {
        setBgMusic(file);
      } else {
        setVoiceOver(file);
      }
    }
  };

  const handleExport = async () => {
    if (!bgMusic || !voiceOver) return;
    
    try {
      setIsExporting(true);
      const mixedBlob = await mixAudio(bgMusic, voiceOver, bgVolume, voiceVolume);
      
      const url = URL.createObjectURL(mixedBlob);
      const a = document.createElement('a');
      a.href = url;
      a.download = 'mixed-audio.wav';
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      URL.revokeObjectURL(url);
    } catch (error) {
      console.error('Export failed:', error);
      alert('Failed to export audio. Please try again.');
    } finally {
      setIsExporting(false);
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-indigo-50 to-purple-50 py-12 px-4">
      <div className="max-w-5xl mx-auto">
        <div className="text-center mb-12">
          <h1 className="text-4xl font-bold text-gray-900 mb-4">Audio Mixer Pro</h1>
          <p className="text-lg text-gray-600">Mix your voice-over with background music professionally</p>
          <p className="text-sm text-gray-500 mt-2">Background music is automatically kept 50% lower than voice-over</p>
        </div>

        <div className="grid gap-8">
          <div className="grid md:grid-cols-2 gap-6">
            <div className="relative group">
              <input
                type="file"
                onChange={(e) => handleFileUpload(e, 'bg')}
                accept="audio/*"
                className="hidden"
                id="bg-music"
              />
              <label
                htmlFor="bg-music"
                className="flex flex-col items-center justify-center p-8 border-2 border-dashed border-indigo-300 rounded-xl bg-white cursor-pointer group-hover:border-indigo-500 transition-colors"
              >
                <Music className="w-12 h-12 text-indigo-500 mb-4" />
                <span className="text-lg font-medium text-gray-700">
                  {bgMusic ? bgMusic.name : 'Upload Background Music'}
                </span>
                <span className="text-sm text-gray-500 mt-2">Click to browse files</span>
              </label>
            </div>

            <div className="relative group">
              <input
                type="file"
                onChange={(e) => handleFileUpload(e, 'voice')}
                accept="audio/*"
                className="hidden"
                id="voice-over"
              />
              <label
                htmlFor="voice-over"
                className="flex flex-col items-center justify-center p-8 border-2 border-dashed border-indigo-300 rounded-xl bg-white cursor-pointer group-hover:border-indigo-500 transition-colors"
              >
                <Mic className="w-12 h-12 text-indigo-500 mb-4" />
                <span className="text-lg font-medium text-gray-700">
                  {voiceOver ? voiceOver.name : 'Upload Voice-over'}
                </span>
                <span className="text-sm text-gray-500 mt-2">Click to browse files</span>
              </label>
            </div>
          </div>

          {bgMusic && (
            <AudioTrack
              file={bgMusic}
              volume={bgVolume}
              onVolumeChange={handleBgVolumeChange}
              label="Background Music"
              isLoop={true}
              maxVolume={voiceVolume * 0.5}
            />
          )}
          
          {voiceOver && (
            <AudioTrack
              file={voiceOver}
              volume={voiceVolume}
              onVolumeChange={handleVoiceVolumeChange}
              label="Voice-over"
            />
          )}

          {bgMusic && voiceOver && (
            <button
              onClick={handleExport}
              disabled={isExporting}
              className={`flex items-center justify-center gap-2 px-6 py-3 bg-indigo-600 text-white rounded-lg transition-colors mx-auto mt-4 ${
                isExporting ? 'opacity-50 cursor-not-allowed' : 'hover:bg-indigo-700'
              }`}
            >
              <Download size={20} />
              <span>{isExporting ? 'Exporting...' : 'Export Mixed Audio'}</span>
            </button>
          )}
        </div>
      </div>
    </div>
  );
}

export default App;